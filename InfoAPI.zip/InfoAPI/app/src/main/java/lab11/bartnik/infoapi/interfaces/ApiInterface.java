package lab11.bartnik.infoapi.interfaces;

import lab11.bartnik.infoapi.domain.IPInfo;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {

    @GET("geo")
    Call<IPInfo> getIPInfo();
}
