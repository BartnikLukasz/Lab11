package lab11.bartnik.infoapi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.InputFilter;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

import lab11.bartnik.infoapi.domain.IPInfo;
import lab11.bartnik.infoapi.filters.MinMaxFilter;
import lab11.bartnik.infoapi.interfaces.ApiInterface;
import lab11.bartnik.infoapi.services.ServiceGenerator;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    EditText e1;
    EditText e2;
    EditText e3;
    EditText e4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = (EditText) findViewById(R.id.ip1);
        e2 = (EditText) findViewById(R.id.ip2);
        e3 = (EditText) findViewById(R.id.ip3);
        e4 = (EditText) findViewById(R.id.ip4);

        e1.setFilters(new InputFilter[]{ new MinMaxFilter( "1" , "255" )});
        e2.setFilters(new InputFilter[]{ new MinMaxFilter( "1" , "255" )});
        e3.setFilters(new InputFilter[]{ new MinMaxFilter( "1" , "255" )});
        e4.setFilters(new InputFilter[]{ new MinMaxFilter( "1" , "255" )});
    }

    public void buttonPress(View view){  getIPInfo(); }

    private void getIPInfo(){

        ApiInterface apiInterface = ServiceGenerator.createService(ApiInterface.class, getIP());

        Call<IPInfo> call = apiInterface.getIPInfo();

        call.enqueue(new Callback<IPInfo>() {
            @Override
            public void onResponse(Call<IPInfo> call, Response<IPInfo> response) {
                printInfo(response.body());
            }

            @Override
            public void onFailure(Call<IPInfo> call, Throwable t) {
                printInfo(null);
            }
        });
    }

    private String getIP() {
        ArrayList<String> ipList = new ArrayList<>();
        ipList.add(e1.getText().toString());
        ipList.add(e2.getText().toString());
        ipList.add(e3.getText().toString());
        ipList.add(e4.getText().toString());

        String ip = "";
        for(String ipPart: ipList){
            if(isIpPartValid(ipPart)){
                ip = StringUtils.join(ip, ipPart, ".");
            }
            else{
                return null;
            }
        }

        return StringUtils.chop(ip);
    }

    private void printInfo(IPInfo info) {
        TextView textView = (TextView) findViewById(R.id.textView);

        String s;

        if(info == null) s = "Failed";
        else {
            s = info.toString();
        }
        textView.setText(s);
    }

    private Boolean isIpPartValid(String ipPart){
        if(StringUtils.isEmpty(ipPart)) return false;
        return (Integer.parseInt(ipPart) > 0) && (Integer.parseInt(ipPart) < 256);
    }

}